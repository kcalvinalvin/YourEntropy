<TS language="ca" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Feu clic dret per a editar l'adreça o l'etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crea una adreça nova</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nova</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia l'adreça seleccionada al porta-retalls del sistema</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Tanca</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Elimina l'adreça seleccionada actualment de la llista</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Introduïu una adreça o una etiqueta per cercar</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta les dades de la pestanya actual a un fitxer</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exporta</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Esborra</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Trieu l'adreça on enviar les monedes</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Trieu l'adreça on rebre les monedes</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Tria</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Adreces d'enviament</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Adreces de recepció</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Aquestes són les vostres adreces de Bitcoin per enviar els pagaments. Sempre reviseu l'import i l'adreça del destinatari abans de transferir monedes.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copia l'adreça</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Copia l'&amp;etiqueta</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Exporta la llista d'adreces</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Fitxer separat per comes (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>L'exportació ha fallat</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>S'ha produït un error en desar la llista d'adreces a %1. Torneu-ho a provar.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Diàleg de contrasenya</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Introduïu una contrasenya</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Contrasenya nova</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repetiu la contrasenya nova</translation>
    </message>
    <message>
        <source>Show passphrase</source>
        <translation>Mostra la contrasenya</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Xifra la cartera</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Aquesta operació requereix la contrasenya de la cartera per a desblocar-la.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Desbloca la cartera</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Aquesta operació requereix la contrasenya de la cartera per a desxifrar-la.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Desxifra la cartera</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Canvia la contrasenya</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Confirma el xifratge de la cartera</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>Avís: si xifreu la cartera i perdeu la contrasenya, &lt;b&gt;PERDREU TOTS ELS BITCOINS&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Esteu segurs que voleu xifrar la vostra cartera?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Cartera xifrada</translation>
    </message>
    <message>
        <source>Enter the new passphrase for the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Introduïu la contrasenya nova a la cartera.&lt;br/&gt;Utilitzeu una contrasenya de &lt;b&gt;deu o més caràcters aleatoris&lt;/b&gt;, o &lt;b&gt;vuit o més paraules&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase for the wallet.</source>
        <translation>Introduïu la contrasenya antiga i la contrasenya nova a la cartera.</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. </source>
        <translation>S'ha xifrat la cartera.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>IMPORTANT: Tota copia de seguretat del fitxer de la cartera que hàgiu realitzat hauria de ser reemplaçada pel fitxer xifrat de la cartera generat recentment. Per motius de seguretat, les còpies de seguretat anteriors del fitxer de la cartera no xifrada esdevindran inusables tan aviat com comenceu a utilitzar la cartera xifrada nova.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Ha fallat el xifratge de la cartera</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>El xifrat del moneder ha fallat per un error intern. El moneder no ha estat xifrat.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Les contrasenyes introduïdes no coincideixen.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>El desbloqueig del moneder ha fallat</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La contrasenya introduïda per a desxifrar el moneder és incorrecta.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>El desxifrat del moneder ha fallat</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>La contrasenya del moneder ha estat canviada correctament.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Avís: Les lletres majúscules estan activades!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP / Màscara de xarxa</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Bandejat fins</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Signa el &amp;missatge...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>S'està sincronitzant amb la xarxa ...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Visió general</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Mostra una visió general del moneder</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaccions</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Explora l'historial de transaccions</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>S&amp;urt</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Surt de l'aplicació</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>Qu&amp;ant al %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Mosta informació sobre el %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Quant a &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Mostra informació sobre Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opcions...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Modifica les opcions de configuració de %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Encripta la cartera...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Realitza una còpia de seguretat del moneder...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Canvia la contrasenya...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Obre un &amp;URI...</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation>Moneder:</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Feu clic per inhabilitar l'activitat de la xarxa.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>S'ha inhabilitat l'activitat de la xarxa.</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Realitza una còpia de seguretat de la cartera a una altra ubicació</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Canvia la contrasenya d'encriptació de la cartera</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Encripta les claus privades pertanyents de la cartera</translation>
    </message>
    <message>
        <source>&amp;Sending addresses</source>
        <translation>Adreces d'&amp;enviament</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses</source>
        <translation>Adreces de &amp;recepció</translation>
    </message>
    <message>
        <source>Open Wallet</source>
        <translation>Obre la cartera</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation>Obre la cartera</translation>
    </message>
    <message>
        <source>Close Wallet...</source>
        <translation>Tanca la cartera...</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation>Tanca la cartera</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation>cartera predeterminada</translation>
    </message>
    <message>
        <source>No wallets available</source>
        <translation>No hi ha cap cartera disponible</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Escala</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation>Finestra principal</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Avís: %1</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation>Cartera: %1
</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>Clau privada &lt;b&gt;inhabilitada&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>La cartera està &lt;b&gt;encriptada&lt;/b&gt; i actualment &lt;b&gt;desblocada&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>La cartera està &lt;b&gt;encriptada&lt;/b&gt; i actualment &lt;b&gt;blocada&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Quantitat:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Import:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Comissió:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polsim:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Comissió posterior:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Canvi:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia l'etiqueta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l'import</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copia la quantitat</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copia la comissió</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copia la comissió posterior</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copia els bytes</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Copia el polsim</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copia el canvi</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
    </context>
<context>
    <name>CreateWalletActivity</name>
    </context>
<context>
    <name>CreateWalletDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>No s'ha pogut desblocar la cartera.</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation>La cartera també serà emmagatzemat en aquest directori.</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the bitcoin network, as detailed below.</source>
        <translation>És possible que les transaccions recents encara no siguin visibles i, per tant, el saldo de la vostra cartera podria ser incorrecte. Aquesta informació serà correcta una vegada que la cartera hagi finalitzat la sincronització amb la xarxa bitcoin, tal com es detalla més avall.</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Últim temps de bloc</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Amaga</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1, %2%)...</source>
        <translation>Desconegut. Sincronització de les capçaleres (%1, %2%)...</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OpenWalletActivity</name>
    <message>
        <source>default wallet</source>
        <translation>moneder per defecte</translation>
    </message>
    <message>
        <source>Opening Wallet &lt;b&gt;%1&lt;/b&gt;...</source>
        <translation>S'està obrint la cartera &lt;b&gt;%1&lt;/b&gt;...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>La informació mostrada pot no estar al dia. El vostra cartera se sincronitza automàticament amb la xarxa Bitcoin un cop s'ha establert connexió, però aquest proces encara no ha finalitzat.</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>You are using a BIP70 URL which will be unsupported in the future.</source>
        <translation>Esteu fent servir un URL BIP70, que podria no tenir suport en el futur.</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Agent d'usuari</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Enviat</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Rebut</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" does not exist.</source>
        <translation>Error: El directori de dades especificat «%1» no existeix.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1.</source>
        <translation>Error: No es pot interpretar el fitxer de configuració: %1.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Avís: %1</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>De&amp;sa la imatge...</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI resultant massa llarga, intenta reduir el text per a la etiqueta / missatge</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Error en codificar l'URI en un codi QR.</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Blocksdir</source>
        <translation>Directori de blocs</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Nombre de connexions</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Cadena de blocs</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Nombre de blocs actuals</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Reserva de memòria</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Nombre actual de transaccions</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Ús de memòria</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation>Cartera:</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(cap)</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Reinicialitza</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Rebut</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Enviat</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Iguals</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Iguals bandejats</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Seleccioneu un igual per mostrar informació detallada.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>A la llista blanca</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Direcció</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Bloc d'inici</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Capçaleres sincronitzades</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Blocs sincronitzats</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Agent d'usuari</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Obre el fitxer de registre de depuració %1 del directori de dades actual. Això pot trigar uns segons en fitxers de registre grans.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Disminueix la mida de la lletra</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Augmenta la mida de la lletra</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Serveis</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Puntuació de bandeig</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Temps de connexió</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Darrer enviament</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Darrera recepció</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Temps de ping</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>La duració d'un ping més destacat actualment.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Espera de ping</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Diferència horària</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Últim temps de bloc</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Obre</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Consola</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>Trà&amp;nsit de la xarxa</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totals</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Dins:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Fora:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Fitxer de registre de depuració</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Neteja la consola</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;hora</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;dia</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;setmana</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;any</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>&amp;Desconnecta</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>Bandeja per</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>&amp;Desbandeja</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Us donem la benvinguda a la consola RPC de %1</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramifications of a command.</source>
        <translation>ADVERTIMENT: Els estafadors han estat actius, dient als usuaris que escriguin ordres aquí, robant els contingut de les seves carteres. No utilitzeu aquesta consola sense comprendre completament les ramificacions d'una ordre.</translation>
    </message>
    <message>
        <source>Executing command without any wallet</source>
        <translation>S'està executant l'ordre sense cap cartera</translation>
    </message>
    <message>
        <source>Executing command using "%1" wallet</source>
        <translation>S'està executant comanda usant la cartera "%1"</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>a través de %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>mai</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Entrant</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Sortint</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Im&amp;port:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Missatge:</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Neteja tots els camps del formulari.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Neteja</translation>
    </message>
    <message>
        <source>Native segwit addresses (aka Bech32 or BIP-173) reduce your transaction fees later on and offer better protection against typos, but old wallets don't support them. When unchecked, an address compatible with older wallets will be created instead.</source>
        <translation>Les adreces segwit natives (més conegudes com Bech32 o BIP-173) redueixen les vostres comisions de les transaccions i ofereixen millor protecció contra errades tipogràfiques, però els moneders antics no les suporten. Quan desmarqui la casella, es generarà una adreça compatible amb moneders antics.</translation>
    </message>
    <message>
        <source>Generate native segwit (Bech32) address</source>
        <translation>Generar una adreça segwit nativa (Bech32)</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Copia l'URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia l'etiqueta</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Copia el missatge</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l'import</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Codi QR</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Copia l'&amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Copia l'&amp;adreça</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>De&amp;sa la imatge...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Sol·licita un pagament a %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Informació de pagament</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Cartera</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(sense missatge)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(no s'ha sol·licitat import)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>Sol·licitat</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Envia monedes</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Característiques de control de les monedes</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Entrades...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>seleccionat automàticament</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Fons insuficients!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Quantitat:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Import:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Comissió:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Comissió posterior:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Canvi:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Comissió de transacció</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Tria...</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>per kilobyte</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Amaga</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Recomanada:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Personalitzada:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation>(No s'ha inicialitzat encara la comissió intel·ligent. Normalment pren uns pocs blocs...)</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Envia a múltiples destinataris al mateix temps</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Afegeix &amp;destinatari</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Neteja tots els camps del formulari.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Polsim:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Neteja-ho &amp;tot</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Copia la quantitat</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l'import</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Copia la comissió</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Copia la comissió posterior</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Copia els bytes</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Copia el polsim</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Copia el canvi</translation>
    </message>
    <message>
        <source>%1 (%2 blocks)</source>
        <translation>%1 (%2 blocs)</translation>
    </message>
    <message>
        <source> from wallet '%1'</source>
        <translation>de la cartera "%1"</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Esteu segur que ho voleu enviar?</translation>
    </message>
    <message>
        <source>or</source>
        <translation>o</translation>
    </message>
    <message>
        <source>You can increase the fee later (signals Replace-By-Fee, BIP-125).</source>
        <translation>Pot incrementar la comissió més tard (senyala Replace-By-Fee o substitució per comissió, BIP-125).</translation>
    </message>
    <message>
        <source>Please, review your transaction.</source>
        <translation>Reviseu la transacció</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Comissió de transacció</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation>Import total</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Confirma l'enviament de monedes</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>L'adreça que heu seleccionat per al canvi no és part d'aquesta cartera. Tots els fons de la vostra cartera es poden enviar a aquesta adreça. N'esteu segur?</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alta+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Enganxa l'adreça del porta-retalls</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation>Usa el saldo disponible</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Missatge:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>Aquesta és una sol·licitud de pagament no autenticada.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>Aquesta és una sol·licitud de pagament autenticada.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Paga a:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Introduïu una etiqueta per a aquesta adreça per afegir-la a la llibreta d'adreces</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 s'està tancant ...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>No apagueu l'ordinador fins que no desaparegui aquesta finestra.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signatures - Signa o verifica un missatge</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signa el missatge</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alta+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Enganxa l'adreça del porta-retalls</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Introduïu aquí el missatge que voleu signar</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatura</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Neteja-ho &amp;tot</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>S'ha cancel·lat el desblocatge de la cartera.</translation>
    </message>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Comissió de transacció</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <source>Transaction virtual size</source>
        <translation>Mida virtual de la transacció</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Import</translation>
    </message>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sense etiqueta)</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Enter address, transaction id, or label to search</source>
        <translation>Introduïu una adreça, la id de la transacció o l'etiqueta per a cercar</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia l'etiqueta</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copia l'import</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Fitxer separat per comes (*.csv)</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>L'exportació ha fallat</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation>Tanca la cartera</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>No s'ha carregat cap cartera.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Envia monedes</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation>cartera predeterminada</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exporta</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta les dades de la pestanya actual a un fitxer</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Còpia de seguretat de la cartera</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Dades de cartera (*.dat)</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>S'ha produït un error en provar de desar les dades de la cartera a %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>S'han desat correctament %1 les dades de la cartera a .</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Poda: la darrera sincronització de la cartera va més enllà de les dades podades. Cal que activeu -reindex (baixeu tota la cadena de blocs de nou en cas de node podat)</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Error inicialitzant l'entorn de la base de dades de la cartera %s!</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>S'ha produït un error en carregar %s: la cartera és corrupta</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>S'ha produït un error en carregar %s: la cartera requereix una versió més nova de %s</translation>
    </message>
    <message>
        <source>Unable to generate keys</source>
        <translation>No s'han pogut generar les claus</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Cal tornar a escriure la cartera: reinicieu %s per a completar-ho</translation>
    </message>
    <message>
        <source>Section [%s] is not recognized.</source>
        <translation>No es reconeix la secció [%s]</translation>
    </message>
    <message>
        <source>Unable to generate initial keys</source>
        <translation>No s'han pogut generar les claus inicials</translation>
    </message>
    <message>
        <source>Verifying wallet(s)...</source>
        <translation>S'estan verificant les carteres...</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Se suprimeixen totes les transaccions de la cartera..</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Advertència: la cartera és malmesa, les dades es recuperen! Original %s desat com a %s en %s; si el vostre saldo o transaccions són incorrectes, haureu de restaurar des d'una còpia de seguretat.</translation>
    </message>
    <message>
        <source>Error loading wallet %s. Duplicate -wallet filename specified.</source>
        <translation>S'ha produït un error en carregar la cartera %s. S'ha especificat un nom de fitxer duplicat -wallet.</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation>La cartera evitarà pagar menys de la comissió de tramesa mínima</translation>
    </message>
    <message>
        <source>Cannot write to data directory '%s'; check permissions.</source>
        <translation>No es pot escriure en el directori de dades "%s". Reviseu-ne els permisos.</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>S'està carregant la cartera...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>No es pot reduir la versió de la cartera</translation>
    </message>
    </context>
</TS>